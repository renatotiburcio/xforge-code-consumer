# PIS/COFINS

Contribuicoes sociais sobre receita.
Aliquotas padrao (RN-002):
PIS: 1.65
COFINS: 7.6
