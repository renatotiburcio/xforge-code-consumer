# ICMS

Imposto sobre Circulacao de Mercadorias e Servicos.
Aliquotas padrao por UF (RN-001):
AC: 17
AL: 17
AP: 18
AM: 18
BA: 18
CE: 18
DF: 18
ES: 17
GO: 17
MA: 18
MT: 17
MS: 17
MG: 18
PA: 17
PB: 18
PR: 18
PE: 18
PI: 18
RJ: 20
RN: 18
RS: 18
RO: 17.5
RR: 17
SC: 17
SP: 18
SE: 18
TO: 18
